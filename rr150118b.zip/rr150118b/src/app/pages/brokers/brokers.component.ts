import { Component, OnInit } from '@angular/core';
import { Injectable, EventEmitter } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

import { Usuario } from '../login/usuario';
import { TokenService } from '../../token.service';
import { BrokersService } from './brokers.service';
import { Observable } from 'rxjs/Observable';

@Component({
  selector: 'app-brokers',
  templateUrl: './brokers.component.html',
  styleUrls: ['./brokers.component.css'],
  providers: [Usuario]
})

@Injectable()
export class BrokersComponent implements OnInit {

  constructor(private usuario: Usuario, public token: TokenService, private http: HttpClient, public brokers: BrokersService) { }

  ngOnInit() {

    console.log('usertoken', this.token.userToken)

    const urlGetCompany = 'http://172.18.164.6:9082/cadu-orbitall/v1/broker';
    let headersParam = new HttpHeaders();
    headersParam = headersParam.set('Content-Type', 'application/json');


    console.log('----------------------> acesso headers param', headersParam);
    this.http.get(urlGetCompany, {
        headers: headersParam
          })
    .subscribe(
      data => {
        // this.listaBroker = data[0];
        this.brokers = data['listBroker'];
        console.log('----------------------> acesso broker', data);
      },
      error => {
        console.log('Erro. Se persistir, entre em contato com o suporte técnico.', error);
      }
    );
  }

  // Função para inserir uma broker
  incluiBroker() {
    console.log('incluiBroker');
  }

  // Função para editar uma broker
  editaBroker() {
    console.log('editaBroker');
  }

  // Função para excluir uma broker
  excluiBroker() {
    console.log('excluiBroker');
  }

}
